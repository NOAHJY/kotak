#!/usr/bin/env python3
# serial_bridge_transmit.py
 
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import serial
 
 
class SerialBridgeTransmit(Node):
    def __init__(self):
        super().__init__("serial_bridge_transmit")
        self.port = serial.Serial("/dev/ttyUSB0", 115200, timeout=1)
        self.create_subscription(String, "perintah_serial", self.Kirim, 10)
        self.get_logger().info("Siap mengirim ke STM32")
 
    def Kirim(self, pesan):
        self.get_logger().info(f"yang dikirim: {pesan.data.strip()}")
        self.port.write(pesan.data.encode())
 
 
def main(args=None):
    rclpy.init(args=args)
    node = SerialBridgeTransmit()
    rclpy.spin(node)
    rclpy.shutdown()
 
 
if __name__ == "__main__":
    main()
 