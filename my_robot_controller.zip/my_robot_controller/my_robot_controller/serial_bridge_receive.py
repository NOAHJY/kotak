#!/usr/bin/env python3
# serial_bridge_receive.py
 
import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Float32MultiArray
 
 
class SerialBridgeReceive(Node):
    def __init__(self):
        super().__init__("serial_bridge_receive")
        self.pub = self.create_publisher(String, "perintah_serial", 10)
        self.create_subscription(String, "perintah_robot", self.Memproses, 10)
        self.create_subscription(Float32MultiArray, "hasil_kinematik", self.MemprosesKinematik, 10)
        self.get_logger().info("Siap menerima perintah")
 
    def Kirim(self, teks):
        pesan = String()
        pesan.data = teks
        self.pub.publish(pesan)
 
    def Memproses(self, pesan):
        if pesan.data == "maju":
            self.Kirim("m")
        elif pesan.data == "mundur":
            self.Kirim("u")
        elif pesan.data == "stop":
            self.Kirim("s")
        else:
            self.get_logger().warn("INVALID")
 
    def MemprosesKinematik(self, pesan):
        if len(pesan.data) < 3:
            return
        u1, u2, u3 = [round(a) for a in pesan.data[:3]]
        self.Kirim(f"W,{u1},{u2},{u3}\n")
 
 
def main(args=None):
    rclpy.init(args=args)
    node = SerialBridgeReceive()
    rclpy.spin(node)
    rclpy.shutdown()
 
 
if __name__ == "__main__":
    main()
 