#!/usr/bin/env python3
import rclpy
from rclpy.node import Node

class Mynode(Node):

    def __init__(self):
        super().__init__("first_node")
        self.create_timer(1.0, self.timer_callback)

    def timer_callback(self):
        self.get_logger().info("Hello from taufiq")

def main (args=None):
    rclpy.init(args=args)#first linenya
    node = Mynode()
    rclpy.spin(node)#akan terus running sampai di stop



    rclpy.shutdown#akhir line


if  __name__ == '__main__':
    main()

