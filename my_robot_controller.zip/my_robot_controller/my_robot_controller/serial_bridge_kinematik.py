#!/usr/bin/env python3
# serial_bridge_kinematik.py
 
import math
import numpy as np
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
 
d = 0.277                  
r = 0.12                   
V_MAX = 1.0                
W_MAX = V_MAX / d          
U_MAX = V_MAX / r         
 
sudut = math.pi / 3
sin = math.sin(sudut)
 

m_rumus = np.array([
    [-d, 1, 0],
    [-d, (-1 / 2), -sin],
    [-d, (-1 / 2), sin]
])
 
 
class InverseKinematik(Node):
    def __init__(self):
        super().__init__("inverse_kinematik")
        self.subscriber = self.create_subscription(
            Float32MultiArray, "posisi_joystick", self.hitung_kinematik, 10)
        self.publisher_kinematik = self.create_publisher(
            Float32MultiArray, "hasil_kinematik", 10)
        self.get_logger().info("Siap menghitung")
 
    def hitung_kinematik(self, msg):
        if len(msg.data) < 3:
            self.get_logger().warn("posisi_joystick harus berisi [x, y, z]")
            return
 
        x = msg.data[0]
        y = msg.data[1]
        z = msg.data[2]
        self.get_logger().info(f"Joystick X: {x}, Y: {y}, Z: {z}")
 
        vx = x / 100 * V_MAX
        vy = y / 100 * V_MAX
        wz = z / 100 * W_MAX
        m_kecper = np.array([
            [wz],
            [vx],
            [vy]
        ])
 
        u = (1 / r) * (m_rumus @ m_kecper)       
        persen = u / U_MAX * 100                 
 
    
        terbesar = float(np.max(np.abs(persen)))
        if terbesar > 100:
            persen = persen * 100 / terbesar
 
        self.kirim_kecepatan(persen)
 
    def kirim_kecepatan(self, persen):
        u1 = float(persen[0, 0])
        u2 = float(persen[1, 0])
        u3 = float(persen[2, 0])
        kirim = Float32MultiArray()
        kirim.data = [u1, u2, u3]
        self.publisher_kinematik.publish(kirim)
        self.get_logger().info(f"Hasil kinematik: U1={u1:.1f}, U2={u2:.1f}, U3={u3:.1f}")
 
 
def main(args=None):
    rclpy.init(args=args)
    node = InverseKinematik()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
 
 
if __name__ == "__main__":
    main()
 