from setuptools import find_packages, setup

package_name = 'my_robot_controller'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='taufiq',
    maintainer_email='taufiq@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            "test_node = my_robot_controller.my_first_node:main",
            "serial_bridge_transmit = my_robot_controller.serial_bridge_transmit:main",
            "serial_bridge_receive = my_robot_controller.serial_bridge_receive:main",
            "serial_bridge_kinematik = my_robot_controller.serial_bridge_kinematik:main",
        ],
    },
)
