import base64
import binascii
import codecs
import re
import string
from urllib.parse import quote, unquote


def EncodeBase64(teks):
    return base64.b64encode(teks.encode("utf-8")).decode("utf-8")


def DecodeBase64(teks):
    return base64.b64decode(teks, validate=True).decode("utf-8")


def EncodeBase32(teks):
    return base64.b32encode(teks.encode("utf-8")).decode("utf-8")


def DecodeBase32(teks):
    return base64.b32decode(teks, casefold=True).decode("utf-8")


def EncodeHex(teks):
    return teks.encode("utf-8").hex()


def DecodeHex(teks):
    return bytes.fromhex(teks).decode("utf-8")


def EncodeURL(teks):
    return quote(teks)


def DecodeURL(teks):
    return unquote(teks)


def Rot13(teks):
    return codecs.decode(teks, "rot_13")


def CariFlag(teks):
    hasil = re.search(r"FGTE\{[^}]*\}", teks)
    if hasil:
        return hasil.group()
    return ""


def DecodeBase64Berulang(teks):
    padding = "=" * ((4 - len(teks) % 4) % 4)
    return base64.b64decode(teks + padding, validate=True).decode("utf-8")


def DecodeBerulang(teks):
    hasil = teks.replace(" ", "").replace("\n", "").strip()
    tahap = 1

    # Urutan pertama sesuai pola soal: ROT13, lalu Base64.
    hasil = Rot13(hasil)
    print("Tahap", tahap, "(ROT13):", hasil)

    while tahap < 50:
        flag = CariFlag(hasil)
        if flag:
            print("\nFlag ditemukan:", flag)
            return

        try:
            hasil = DecodeBase64Berulang(hasil)
        except (binascii.Error, UnicodeDecodeError):
            print("\nBase64 tidak valid pada tahap berikutnya.")
            return

        tahap += 1
        print("Tahap", tahap, "(Base64):", hasil)

        flag = CariFlag(hasil)
        if flag:
            print("\nFlag ditemukan:", flag)
            return

        hasil = Rot13(hasil)
        tahap += 1
        print("Tahap", tahap, "(ROT13):", hasil)

    print("\nFlag tidak ditemukan setelah 50 tahap.")


def Caesar(teks, geser):
    hasil = ""

    for karakter in teks:
        if karakter.isupper():
            hasil += chr((ord(karakter) - ord("A") + geser) % 26 + ord("A"))
        elif karakter.islower():
            hasil += chr((ord(karakter) - ord("a") + geser) % 26 + ord("a"))
        else:
            hasil += karakter

    return hasil


def ApakahTeks(teks):
    for karakter in teks:
        if karakter not in string.printable:
            return False
    return True


def Analisis(teks):
    print("\nHasil analisis:")
    print("Catatan: analisis ini adalah dugaan berdasarkan pola, bukan kepastian.")

    if "%" in teks and re.search(r"%[0-9A-Fa-f]{2}", teks):
        print("- Kemungkinan URL encoding")

    if re.fullmatch(r"[0-9A-Fa-f]+", teks) and len(teks) % 2 == 0:
        print("- Kemungkinan Hexadecimal atau Base16")

    if re.fullmatch(r"[A-Za-z0-9+/]+={0,2}", teks) and len(teks) % 4 == 0:
        try:
            hasil = DecodeBase64(teks)
            if ApakahTeks(hasil):
                print("- Kemungkinan Base64")
        except (ValueError, UnicodeDecodeError):
            pass

    if re.fullmatch(r"[A-Za-z2-7]+=*", teks.upper()):
        try:
            hasil = DecodeBase32(teks)
            if ApakahTeks(hasil):
                print("- Kemungkinan Base32")
        except (ValueError, UnicodeDecodeError):
            pass

    print("- ROT13 dan Caesar Cipher tidak dapat dipastikan hanya dari bentuk teks.")
    print("- Jika teks hanya huruf, cobalah menu Caesar atau ROT13.")


def PilihMetode():
    print("\nPilih metode:")
    print("1. Base64")
    print("2. Base32")
    print("3. Hexadecimal / Base16")
    print("4. URL encoding")
    print("5. ROT13")
    print("6. Caesar Cipher")
    return input("Pilihan: ")


def Encode():
    metode = PilihMetode()
    teks = input("Masukkan teks: ")

    if metode == "1":
        hasil = EncodeBase64(teks)
    elif metode == "2":
        hasil = EncodeBase32(teks)
    elif metode == "3":
        hasil = EncodeHex(teks)
    elif metode == "4":
        hasil = EncodeURL(teks)
    elif metode == "5":
        hasil = Rot13(teks)
    elif metode == "6":
        geser = int(input("Masukkan jumlah geser: "))
        hasil = Caesar(teks, geser)
    else:
        print("Pilihan tidak tersedia.")
        return

    print("Hasil encode:", hasil)


def Decode():
    metode = PilihMetode()
    teks = input("Masukkan teks kode: ")

    try:
        if metode == "1":
            hasil = DecodeBase64(teks)
        elif metode == "2":
            hasil = DecodeBase32(teks)
        elif metode == "3":
            hasil = DecodeHex(teks)
        elif metode == "4":
            hasil = DecodeURL(teks)
        elif metode == "5":
            hasil = Rot13(teks)
        elif metode == "6":
            geser = int(input("Masukkan jumlah geser: "))
            hasil = Caesar(teks, -geser)
        else:
            print("Pilihan tidak tersedia.")
            return

        print("Hasil decode:", hasil)
    except (ValueError, UnicodeDecodeError):
        print("Teks tidak sesuai dengan metode yang dipilih.")


def Main():
    while True:
        print("\n=== PROGRAM ENCODE, DECODE, DAN ANALISIS ===")
        print("1. Encode")
        print("2. Decode")
        print("3. Analisis kode")
        print("4. Decode berulang ROT13 dan Base64")
        print("0. Keluar")

        pilihan = input("Pilihan: ")

        if pilihan == "1":
            Encode()
        elif pilihan == "2":
            Decode()
        elif pilihan == "3":
            teks = input("Masukkan teks kode: ")
            Analisis(teks)
        elif pilihan == "4":
            teks = input("Masukkan kode berulang: ")
            DecodeBerulang(teks)
        elif pilihan == "0":
            print("Program selesai.")
            break
        else:
            print("Pilihan tidak tersedia.")


Main()
