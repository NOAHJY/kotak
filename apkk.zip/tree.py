def makePN(A, C):
     return (A, C)
 
def Akar(PN):
     return PN[0]
 
def Anak(PN):
     return PN[1]
 
def IsTreeEmpty(PN):
     return PN == []
 
def IsOneElmt(PN):
     return not IsTreeEmpty(PN) and IsTreeEmpty(Anak(PN))
 
def NbElmt(PN):
     if IsTreeEmpty(PN):
         return 0
     return 1 + NbElmt(Anak(PN))
def NBNElmtChild(PN):
     if IsTreeEmpty(PN):
         return 0
     elif IsOneElmt(PN):
         return 1
     return NBNElmtChild(Anak(PN))
 
def NBNDaun(PN):
     if IsTreeEmpty(PN):
         return 0
     elif IsOneElmt(PN):
         return 1
     return NBNElmtChild(Anak(PN))
 
def isMemberPN(x, P):
    if IsTreeEmpty(P):
        return False
    if Akar(P) == x:
        return True
    return isMemberPN(x, Anak(P))

P = ((2, [(3,[(1, []),(4, []),(5,[(9, [])])]),(7,[(6, []),(8, [])])])) 
print(NbElmt(P)) 
print(NBNElmtChild(P))
print(NBNDaun(P))
print(isMemberPN(9, P))