# Nama : Ilham Maulana Syahid
# NIM  : 24060126120039

from list_24060126120039 import *

def isEmpty(s: list[list]) -> bool:
    return s == []

def isAtom(s: list[list]) -> bool:
    return type(s) != list

print("isAtom:", isAtom([1, 2, 3]))

def isList(s: list[list]) -> bool:
    return type(s) == list

print("isList:", isList([1, 2, 3]))

def konsLo(s: list[list], l: list[list]) -> list[list]:
    return [s] + l

print("konsLo:", konsLo(1, [2, 3]))

def konsLi(s: list[list], l: list[list]) -> list[list]:
    return l + [s]

print("konsLi:", konsLi(1, [2, 3]))

def firstList(s: list[list]) -> list[list]:
    return s[0]
print("firstList:", firstList([1, 2, 3]))

def lastList(s: list[list]) -> list[list]:
    return s[-1]
print("lastList:", lastList([1, 2, 3]))

def tailList(s: list[list]) -> list[list]:
    return s[1:]

def headList(s: list[list]) -> list[list]:
    return s[:-1]

def IsMemberLS(x: list, s: list[list]) -> bool:
    if isEmpty(s):
        return False
    elif firstList(s) == x:
        return True
    return IsMemberLS(x, tailList(s))

print("IsMemberLS:", IsMemberLS([1, 2], [[1, 2], [3, 4]]))


# --------------------Tugas Latihan--------------------
# DEFINISI DAN SPESIFIKASI
# IsMemberS: elemen, list of list -> boolean
# {IsMemberS(x,S) mengembalikan true jika elemen x ada di dalam list of list S.}

# Realisasi
def IsMemberS(x: int, s: list[list]) -> bool:
    if isEmpty(s):
        return False
    elif firstList(s) == x:
        return True
    return IsMemberS(x, tailList(s))

# Aplikasi:
print(IsMemberS(3, [])) # False
print(IsMemberS(3, [2, 4, 3, [1], [4,5]])) # True
print(IsMemberS(3, [2, 4, 7, [1], [3,5]]))  # True
#-----------------------------------------------

# DEFINISI DAN SPESIFIKASI
# RemberList: elemen, List of List -> List of List
# {RemberList(x,S) menghapus semua elemen x yang ada di list of list S.

# Realisasi
def RemberList(x : int, s: list[list]) -> list[list]:
    if isEmpty(s):
        return []
    elif firstList(s) == x:
        return RemberList(x, tailList(s))
    return konsLo(firstList(s), RemberList(x, tailList(s)))

# aplikasi:
print(RemberList(3, [4, 3, [2,4], 3]))
print(RemberList(4, [2, 4, [3,6,9], 5, 3]))
#------------------------------------

#DEFINISI DAN SPESIFIKASI
# MaxLOL: List of List -> integer
# Definisi dan spesifikasi:
# {MaxLOL(S) mengembalikan nilai maksimum dari semua atom di dalam S.
#  List yang menjadi elemen S dianggap sebagai satu kelompok atom.}

# Realisasi:
def MaxLOL(s: list) -> int:
    if isEmpty(s):
        return 0
    if isAtom(firstList(s)):
        nilai = firstList(s)
    elif isEmpty(firstList(s)):
        return MaxLOL(tailList(s))
    else:
        nilai = MaxLOL(firstList(s))
    if isEmpty(tailList(s)):
        return nilai
    return max(nilai, MaxLOL(tailList(s)))

# Contoh aplikasi:
print("MaxLOL:", MaxLOL([4, 5, 6, [8, 9, 10], [12, 0], 8]))  # 12
print("MaxLOL:", MaxLOL([4, 15, 6, [8, 9, 10], [12, 0], 8]))  # 15
#-----------------------------------------------

# DEFINISI DAN SPESIFIKASI
# NBElmtAtom: List of List -> integer
# Definisi dan spesifikasi:
# {NBElmtAtom(S) mengembalikan banyaknya elemen S yang berupa atom.}

# Realisasi:
def NBElmtAtom(s: list) -> int:
    if isEmpty(s):
        return 0
    if isAtom(firstList(s)):
        return 1 + NBElmtAtom(tailList(s))
    return NBElmtAtom(tailList(s))

# Aplikasi:
print("NBElmtAtom:", NBElmtAtom([4, 5, 6, [8, 9, 10], [12, 0], 8]))  # 4
print("NBElmtAtom:", NBElmtAtom([4, 15, 6, [8, 9], 10, [12], 8]))  # 5
print("NBElmtAtom:", NBElmtAtom([[8, 9, 10]]))  # 0
#-----------------------------------------------

# DEFINISI DAN SPESIFIKASI
# NBElmtList: List of List -> integer
# Definisi dan spesifikasi:
# {NBElmtList(S) mengembalikan banyaknya elemen S yang berupa list.}

# Realisasi:
def NBElmtList(s: list) -> int:
    if isEmpty(s):
        return 0
    if isList(firstList(s)):
        return 1 + NBElmtList(tailList(s))
    return NBElmtList(tailList(s))

# Aplikasi:
print("NBElmtList:", NBElmtList([4, 5, 6, [8, 9, 10], [12, 0], 8]))  # 2
print("NBElmtList:", NBElmtList([[4, 15], 6, [8, 9], 10, [12], 8]))  # 3
print("NBElmtList:", NBElmtList([[8, 9, 10]]))  # 1
#-----------------------------------------------

# DEFINISI DAN SPESIFIKASI
# SumLoL: List of List -> integer
# Definisi dan spesifikasi:
# {SumLoL(S) mengembalikan jumlah seluruh atom di dalam S.
#  Jika elemen S berupa list, jumlah yang digunakan adalah jumlah isi list tersebut.}
# Realisasi:
def SumLoL(s: list) -> int:
    if isEmpty(s):
        return 0
    if isAtom(firstList(s)):
        nilai = firstList(s)
    else:
        nilai = sum(firstList(s))
    return nilai + SumLoL(tailList(s))

# Aplikasi:
print("SumLoL:", SumLoL([[]]))  # 0
print("SumLoL:", SumLoL([4, 5, 6, [2, 3, 1]]))  # 21
print("SumLoL:", SumLoL([[2, 3, 4]]))  # 9
#-----------------------------------------------

# DEFINISI DAN SPESIFIKASI
# MaxNBElmtList: List of List -> integer
# Definisi dan spesifikasi:
# {MaxNBElmtList(S) mengembalikan banyaknya elemen terbanyak dari
#  semua list yang menjadi elemen S. Atom tidak dihitung sebagai list.}

# Realisasi:
def MaxNBElmtList(s: list) -> int:
    if isEmpty(s):
        return 0
    if isAtom(firstList(s)):
        jumlah = 0
    else:
        jumlah = len(firstList(s))
    return max(jumlah, MaxNBElmtList(tailList(s)))

# Aplikasi:
print("MaxNBElmtList:", MaxNBElmtList([[4, 5, 6, 7], [8, 9, 10], [12, 0], 8]))  # 4
print("MaxNBElmtList:", MaxNBElmtList([[4, 15], 6, [8, 9], 10, [12], 8]))  # 2
print("MaxNBElmtList:", MaxNBElmtList([8, 9, 10]))  # 0
#-----------------------------------------------

# DEFINISI DAN SPESIFIKASI
# MaxSumElmt: List of List -> integer
# Definisi dan spesifikasi:
# {MaxSumElmt(S) mengembalikan nilai maksimum dari setiap elemen S.
#  Untuk atom digunakan nilainya, sedangkan untuk list digunakan jumlah
#  elemen di dalam list tersebut.}

# Realisasi:
def MaxSumElmt(s: list) -> int:
    if isEmpty(s):
        return 0
    if isAtom(firstList(s)):
        nilai = firstList(s)
    else:
        nilai = sum(firstList(s))
    if isEmpty(tailList(s)):
        return nilai
    return max(nilai, MaxSumElmt(tailList(s)))

# Aplikasi:
print("MaxSumElmt:", MaxSumElmt([[1, 2], 9, [4, 5, 6], 8]))  # 15
print("MaxSumElmt:", MaxSumElmt([[1, 2], 90, [4, 5, 6], 8]))  # 90
print("MaxSumElmt:", MaxSumElmt([8, 9, 10]))  # 10
print("MaxSumElmt:", MaxSumElmt([[8, 9, 10]]))  # 27