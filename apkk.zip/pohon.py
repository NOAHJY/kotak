# Materi Pohon Biner
#
# Bentuk pohon:
# [akar, subpohon kiri, subpohon kanan]
#
# Pohon kosong:
# []


# DEFINISI DAN SPESIFIKASI
# Akar: Pohon -> elemen
# {Akar(P) menghasilkan elemen yang menjadi akar pohon P.}
def Akar(P):
    return P[0]


# Left: Pohon -> Pohon
# {Left(P) menghasilkan subpohon kiri dari P.}
def Left(P):
    return P[1]


# Right: Pohon -> Pohon
# {Right(P) menghasilkan subpohon kanan dari P.}
def Right(P):
    return P[2]


# IsTreeEmpty: Pohon -> boolean
# {IsTreeEmpty(P) True jika P adalah pohon kosong.}
def IsTreeEmpty(P):
    return P == []


# IsOneElmt: Pohon -> boolean
# {IsOneElmt(P) True jika P hanya memiliki satu elemen.}
def IsOneElmt(P):
    return not IsTreeEmpty(P) and IsTreeEmpty(Left(P)) and IsTreeEmpty(Right(P))


# NbElmt: Pohon -> integer
# {NbElmt(P) menghitung banyak elemen pada pohon P.}
def NbElmt(P):
    if IsTreeEmpty(P):
        return 0
    return 1 + NbElmt(Left(P)) + NbElmt(Right(P))


# NbDaun: Pohon -> integer
# {NbDaun(P) menghitung banyak daun pada pohon P.}
def NbDaun(P):
    if IsTreeEmpty(P):
        return 0
    elif IsOneElmt(P):
        return 1
    return NbDaun(Left(P)) + NbDaun(Right(P))


# Tinggi: Pohon -> integer
# {Tinggi(P) menghitung tinggi pohon P.}
def Tinggi(P):
    if IsTreeEmpty(P):
        return 0
    elif Tinggi(Left(P)) > Tinggi(Right(P)):
        return 1 + Tinggi(Left(P))
    return 1 + Tinggi(Right(P))


# DepthOf: elemen, Pohon -> integer
# {DepthOf(x, P) menghasilkan kedalaman x dari akar P.
#  Akar memiliki depth 0. Jika x tidak ditemukan, hasilnya -1.}
def DepthOf(x, P):
    if IsTreeEmpty(P):
        return -1
    elif Akar(P) == x:
        return 0

    elif DepthOf(x, Left(P)) != -1:
        return 1 + DepthOf(x, Left(P))
    
    elif DepthOf(x, Right(P)) != -1:
        return 1 + DepthOf(x, Right(P))

    else:
        return -1


# IsSameShape: Pohon, Pohon -> boolean
# {IsSameShape(P1, P2) True jika P1 dan P2 memiliki bentuk yang sama,
#  tanpa membandingkan nilai elemennya.}
def IsSameShape(P1, P2):
    if IsTreeEmpty(P1) and IsTreeEmpty(P2):
        return True
    elif IsTreeEmpty(P1) or IsTreeEmpty(P2):
        return False
    return IsSameShape(Left(P1), Left(P2)) and IsSameShape(Right(P1), Right(P2))


# MaxTree: Pohon -> elemen
# {MaxTree(P) menghasilkan elemen terbesar pada pohon P.}
def MaxTree(P):
    if IsTreeEmpty(P):
        raise ValueError("MaxTree tidak dapat digunakan pada pohon kosong")
    return max(PreOrder(P))


# MinTree: Pohon -> elemen
# {MinTree(P) menghasilkan elemen terkecil pada pohon P.}
def MinTree(P):
    if IsTreeEmpty(P):
        raise ValueError("MinTree tidak dapat digunakan pada pohon kosong")
    return min(PreOrder(P))


# PreOrder: Pohon -> List
# {Mengunjungi akar, subpohon kiri, lalu subpohon kanan.}
def PreOrder(P):
    if IsTreeEmpty(P):
        return []
    return [Akar(P)] + PreOrder(Left(P)) + PreOrder(Right(P))


# InOrder: Pohon -> List
# {Mengunjungi subpohon kiri, akar, lalu subpohon kanan.}
def InOrder(P):
    if IsTreeEmpty(P):
        return []
    return InOrder(Left(P)) + [Akar(P)] + InOrder(Right(P))


# PostOrder: Pohon -> List
# {Mengunjungi subpohon kiri, subpohon kanan, lalu akar.}
def PostOrder(P):
    if IsTreeEmpty(P):
        return []
    return PostOrder(Left(P)) + PostOrder(Right(P)) + [Akar(P)]


# IsMember: elemen, Pohon -> boolean
# {IsMember(x, P) True jika x terdapat pada pohon P.}
def IsMember(x, P):
    if IsTreeEmpty(P):
        return False
    elif Akar(P) == x:
        return True
    return IsMember(x, Left(P)) or IsMember(x, Right(P))

def sumTree(P):
    if IsTreeEmpty(P):
        return 0
    return Akar(P) + sumTree(Left(P)) + sumTree(Right(P))

def countEven(P):
    if IsTreeEmpty(P):
        return 0
    elif Akar(P) % 2 == 0 :
        return 1 + countEven(Left(P)) + countEven(Right(P))
    else:
        return countEven(Left(P)) + countEven(Right(P))
    
print(countEven([8, [3, [1, [], []], [6, [], []]], [10, [], [14, [], []]]]))  # Output: 4


# Aplikasi
# Membuat daun terlebih dahulu
Daun1 = [1, [], []]
Daun6 = [6, [], []]
Daun14 = [14, [], []]

# Membuat subpohon kiri dan kanan
SubPohonKiri = [3, Daun1, Daun6]
SubPohonKanan = [10, [], Daun14]



# Membuat pohon utama
P = [8, SubPohonKiri, SubPohonKanan]

print("Akar:", Akar(P))
print("Pohon kosong:", IsTreeEmpty(P))
print("Satu elemen:", IsOneElmt(P))
print("Banyak elemen:", NbElmt(P))
print("Banyak daun:", NbDaun(P))
print("Tinggi:", Tinggi(P))
print("DepthOf(6):", DepthOf(6, P))
print("IsSameShape(P, P):", IsSameShape(P, P))
print("MaxTree:", MaxTree(P))
print("MinTree:", MinTree(P))
print("PreOrder:", PreOrder(P))
print("InOrder:", InOrder(P))
print("PostOrder:", PostOrder(P))
print("IsMember(6):", IsMember(6, P))
