from list_24060126120039 import *


# DEFINISI DAN SPESIFIKASI
# Rember2: elemen, List -> List
# {Rember2(x, L) menghapus satu kemunculan pertama x dari list L.
# Jika x tidak ada di L, maka L tetap. List kosong tetap menjadi list kosong.}
# Realisasi:
def Rember2(x, L: list) -> list:
    if isEmpty(L):  # Basis
        return []
    if FirstElmt(L) == x:  # Rekurens
        return Tail(L)
    return konso(FirstElmt(L), Rember2(x, Tail(L)))


# Aplikasi:
print("Rember2:", Rember2(2, [7, 2, 5, 2, 3]))
print("Rember2:", Rember2(2, []))


# DEFINISI DAN SPESIFIKASI
# MultiRember: elemen, List -> List
# {MultiRember(x, L) menghapus semua kemunculan x dari list L.
# List kosong tetap menjadi list kosong.}
# Realisasi:
def MultiRember(x, L: list) -> list:
    if isEmpty(L):  # Basis
        return []
    if FirstElmt(L) == x:  # Rekurens
        return MultiRember(x, Tail(L))
    return konso(FirstElmt(L), MultiRember(x, Tail(L)))


# Aplikasi:
print("MultiRember:", MultiRember(2, [7, 2, 5, 2, 3]))
print("MultiRember:", MultiRember(2, []))


# DEFINISI DAN SPESIFIKASI
# MakeSet_Versi1: List -> Set
# {MakeSet_Versi1(L) membentuk set dengan mempertahankan kemunculan
# terakhir setiap elemen.}
# Realisasi:
def MakeSet_Versi1(L: list) -> list:
    if isEmpty(L):  # Basis
        return []
    if FirstElmt(L) in Tail(L):  # Rekurens
        return MakeSet_Versi1(Tail(L))
    return konso(FirstElmt(L), MakeSet_Versi1(Tail(L)))


# Aplikasi:
print("MakeSet_Versi1:", MakeSet_Versi1([1, 2, 1, 3, 2]))


# DEFINISI DAN SPESIFIKASI
# MakeSet_Versi2: List -> Set
# {MakeSet_Versi2(L) membentuk set dengan mempertahankan kemunculan
# pertama setiap elemen.}
# Realisasi:
def MakeSet_Versi2(L: list) -> list:
    if isEmpty(L):  # Basis
        return []
    e = FirstElmt(L)  # Rekurens
    return konso(e, MakeSet_Versi2(MultiRember(e, Tail(L))))


# Aplikasi:
print("MakeSet_Versi2:", MakeSet_Versi2([1, 2, 1, 3, 2]))


# DEFINISI DAN SPESIFIKASI
# KonsoSet: elemen, Set -> Set
# {KonsoSet(e, H) menambahkan e sebagai elemen pertama H jika e belum ada.}
# Realisasi:
def KonsoSet(e, H: list) -> list:
    if e in H:  # Basis kondisi
        return H
    return konso(e, H)  # Realisasi penambahan

# Aplikasi:
print("KonsoSet:", KonsoSet(1, [2, 3]))


# DEFINISI DAN SPESIFIKASI
# IsSet: List -> boolean
# {IsSet(L) bernilai True jika L tidak memiliki elemen yang sama.}
# Realisasi:
def IsSet(L: list) -> bool:
    if isEmpty(L):  # Basis
        return True
    return FirstElmt(L) not in Tail(L) and IsSet(Tail(L))  # Rekurens


# Aplikasi:
print("IsSet:", IsSet([1, 2, 3]))
print("IsSet:", IsSet([1, 2, 1]))


# DEFINISI DAN SPESIFIKASI
# IsSubSet: 2 Set -> boolean
# {IsSubSet(H1, H2) bernilai True jika setiap elemen H1 ada di H2.}
# Realisasi:
def IsSubSet(H1: list, H2: list) -> bool:
    if isEmpty(H1):  # Basis
        return True
    return FirstElmt(H1) in H2 and IsSubSet(Tail(H1), H2)  # Rekurens


# Aplikasi:
print("IsSubSet:", IsSubSet([1, 2], [1, 2, 3]))


# DEFINISI DAN SPESIFIKASI
# IsEqualSet_Versi1: 2 Set -> boolean
# {IsEqualSet_Versi1(H1, H2) bernilai True jika H1 dan H2 saling subset.}
# Realisasi:
def IsEqualSet_Versi1(H1: list, H2: list) -> bool:
    return IsSubSet(H1, H2) and IsSubSet(H2, H1)


# Aplikasi:
print("IsEqualSet_Versi1:", IsEqualSet_Versi1([1, 2], [2, 1]))


# DEFINISI DAN SPESIFIKASI
# IsEqualSet_Versi2: 2 Set -> boolean
# {IsEqualSet_Versi2(H1, H2) membandingkan anggota kedua set dan jumlahnya.}
# Realisasi:
def IsEqualSet_Versi2(H1: list, H2: list) -> bool:
    return len(H1) == len(H2) and IsSubSet(H1, H2)


# Aplikasi:
print("IsEqualSet_Versi2:", IsEqualSet_Versi2([1, 2], [2, 1]))


# DEFINISI DAN SPESIFIKASI
# IsIntersect: 2 Set -> boolean
# {IsIntersect(H1, H2) bernilai True jika H1 dan H2 memiliki irisan.}
# Realisasi:
def IsIntersect(H1: list, H2: list) -> bool:
    if isEmpty(H1):  # Basis
        return False
    return FirstElmt(H1) in H2 or IsIntersect(Tail(H1), H2)  # Rekurens


# Aplikasi:
print("IsIntersect:", IsIntersect([1, 2], [2, 3]))


# DEFINISI DAN SPESIFIKASI
# MakeIntersect_Versi1: 2 Set -> Set
# {Menghasilkan irisan dengan urutan mengikuti H1.}
# Realisasi:
def MakeIntersect_Versi1(H1: list, H2: list) -> list:
    if isEmpty(H1):  # Basis
        return []
    if FirstElmt(H1) in H2:  # Rekurens
        return konso(FirstElmt(H1), MakeIntersect_Versi1(Tail(H1), H2))
    return MakeIntersect_Versi1(Tail(H1), H2)


# Aplikasi:
print("MakeIntersect_Versi1:", MakeIntersect_Versi1([3, 1, 2], [2, 3]))


# DEFINISI DAN SPESIFIKASI
# MakeIntersect_Versi2: 2 Set -> Set
# {Menghasilkan irisan dengan urutan mengikuti H2.}
# Realisasi:
def MakeIntersect_Versi2(H1: list, H2: list) -> list:
    return MakeIntersect_Versi1(H2, H1)


# Aplikasi:
print("MakeIntersect_Versi2:", MakeIntersect_Versi2([3, 1, 2], [2, 3]))


# DEFINISI DAN SPESIFIKASI
# MakeUnion_Versi1: 2 Set -> Set
# {Menghasilkan gabungan dengan prioritas urutan H1 lalu H2.}
# Realisasi:
def MakeUnion_Versi1(H1: list, H2: list) -> list:
    return MakeSet_Versi2(H1 + H2)


# Aplikasi:
print("MakeUnion_Versi1:", MakeUnion_Versi1([1, 2], [2, 3]))


# DEFINISI DAN SPESIFIKASI
# MakeUnion_Versi2: 2 Set -> Set
# {Menghasilkan gabungan dengan prioritas urutan H2 lalu H1.}
# Realisasi:
def MakeUnion_Versi2(H1: list, H2: list) -> list:
    return MakeUnion_Versi1(H2, H1)


# Aplikasi:
print("MakeUnion_Versi2:", MakeUnion_Versi2([1, 2], [2, 3]))


# DEFINISI DAN SPESIFIKASI
# NBIntersect: 2 Set -> integer
# {NBIntersect menghasilkan banyak elemen yang beririsan pada H1 dan H2.}
# Realisasi:
def NBIntersect(H1: list, H2: list) -> int:
    if isEmpty(H1):  # Basis
        return 0
    if FirstElmt(H1) in H2:  # Rekurens
        return 1 + NBIntersect(Tail(H1), H2)
    return NBIntersect(Tail(H1), H2)


# Aplikasi:
print("NBIntersect:", NBIntersect([1, 2], [2, 3]))


# DEFINISI DAN SPESIFIKASI
# NBUnion: 2 Set -> integer
# {NBUnion menghasilkan banyak elemen pada gabungan H1 dan H2.}
# Realisasi:
def NBUnion(H1: list, H2: list) -> int:
    return len(MakeUnion_Versi1(H1, H2))


# Aplikasi:
print("NBUnion:", NBUnion([1, 2], [2, 3]))


# DEFINISI DAN SPESIFIKASI
# KonsiSet: Set, elemen -> Set
# {KonsiSet(H, e) menambahkan e sebagai elemen terakhir H jika belum ada.}
# Realisasi:
def KonsiSet(H: list, e) -> list:
    if e in H:  # Basis kondisi
        return H
    return konsi(e, H)


# Aplikasi:
print("KonsiSet:", KonsiSet([1, 2], 3))


# DEFINISI DAN SPESIFIKASI
# MakeDifference: 2 Set -> Set
# {Menghasilkan elemen H1 yang bukan anggota H2.}
# Realisasi:
def MakeDifference(H1: list, H2: list) -> list:
    if isEmpty(H1):  # Basis
        return []
    if FirstElmt(H1) in H2:  # Rekurens
        return MakeDifference(Tail(H1), H2)
    return konso(FirstElmt(H1), MakeDifference(Tail(H1), H2))


# Aplikasi:
print("MakeDifference:", MakeDifference([1, 2, 3], [2]))


# DEFINISI DAN SPESIFIKASI
# MakeSymDifference: 2 Set -> Set
# {Menghasilkan elemen yang hanya ada pada salah satu set.}
# Realisasi:
def MakeSymDifference(H1: list, H2: list) -> list:
    return MakeDifference(H1, H2) + MakeDifference(H2, H1)


# Aplikasi:
print("MakeSymDifference:", MakeSymDifference([1, 2], [2, 3]))


# DEFINISI DAN SPESIFIKASI
# JaccardSimilarity: 2 Set -> real
# {Menghasilkan banyak irisan dibagi banyak gabungan.
# Jika keduanya kosong, hasilnya 0.0.}
# Realisasi:
def JaccardSimilarity(H1: list, H2: list) -> float:
    union = NBUnion(H1, H2)
    if union == 0:  # Basis kondisi
        return 0.0
    return NBIntersect(H1, H2) / union


# Aplikasi:
print("JaccardSimilarity:", JaccardSimilarity([1, 2], [2, 3]))


# DEFINISI DAN SPESIFIKASI
# KonsoAll: elemen, List of List -> List of List
# {KonsoAll(e, LL) menambahkan e di awal setiap list dalam LL.}
# Realisasi:
def KonsoAll(e, LL: list) -> list:
    if isEmpty(LL):  # Basis
        return []
    return konso(konso(e, FirstElmt(LL)), KonsoAll(e, Tail(LL)))


# Aplikasi:
print("KonsoAll:", KonsoAll(1, [[2], [3, 4]]))


# DEFINISI DAN SPESIFIKASI
# PowerSet: Set -> Set of Set
# {PowerSet(H) menghasilkan semua subset H, termasuk set kosong dan H.}
# Realisasi:
def PowerSet(H: list) -> list:
    if isEmpty(H):  # Basis
        return [[]]
    subsets = PowerSet(Tail(H))  # Rekurens
    return subsets + KonsoAll(FirstElmt(H), subsets)


# Aplikasi:
print("PowerSet:", PowerSet([1, 2]))
