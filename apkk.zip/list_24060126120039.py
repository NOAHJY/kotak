def konso(e : int, l : list) -> list :
    return [e] + l
def konsi(e : int, l : list) -> list :
    return l + [e]
def FirstElmt(l:list) -> int:
    return l[0]
def LastElmt(l:list) -> int:
    return l[-1]
def Head(l:list) -> list:
    return l[:-1]
def Tail(l:list) -> list:
    return l[1:]
def isEmpty(l:list) -> bool:
    return l == []
def isOneElmt(l:list) -> bool:
    return Head(l) == [] and Tail(l) == [] and (not isEmpty(l))
# def NbElmt(l:list) -> int:
#     if isEmpty(l):
#         return 0
#     else:
#         return 1 + NbElmt(Tail(l))

# print(NbElmt([2,3,3]))

print(konso(1,[2,3,4]))
print(konsi(1,[2,3,4]))
# # --------------------Tugas Latihan--------------------
# # ElmtKeN: integer ≥ 0, List -> elemen
# # {ElmtKeN(N, L) menghasilkan elemen ke-N dari list L.}
# # Realisasi

# def ElmtKeN(n : int, l : list) -> int: 
#     return l[n]

# def IsMember(n:int, l:list) -> bool:
#     if isEmpty(l):
#         return False
#     elif FirstElmt(l) == n:
#         return True
#     else:
#         return IsMember(n, Tail(l))

# print(ElmtKeN(1, [2,5,3,4]))
# print(IsMember(3,[5,3]))
# print(Tail([5]))

# # Copy: List -> List
# # {Copy(L) menghasilkan List yang identik dengan list asal.}

# def Copy(l:list) -> list:
#     if isEmpty(l):
#         return []
#     else:
#         return konso(FirstElmt(l),Tail(l))

# print(Copy([2,3,5]))

# # Inverse: List -> List
# # {Inverse(L) menghasilkan list L yang dibalik, yaitu
# # yang urutan elemennya adalah kebalikan dari list awal.}

# def Inverse(l:list) -> list:
#     if isEmpty(l):
#         return []
#     else:
#         return konso(LastElmt(l),Inverse(Head(l)))
# print(Inverse([5,6,7]))

# # Konkat: 2 List -> List
# # {Konkat(L1, L2) menghasilkan List yang merupakan hasil konkatenasi # list L1 dan L2.}
# def konkat(l1:list,l2:list) -> list:
#     if isEmpty(l1):
#         return l2
#     else:
#         return konso(FirstElmt(l1), konkat(Tail(l1),l2))

# print(konkat([1,23,3],[2,3,3]))

# def sumlist(l:list) -> int:
#     if isEmpty(l):
#         return 0
#     else:
#         return FirstElmt(l) + sumlist(Tail(l))

# print(sumlist([1,2,3,4,5]))

# # AvgElmt(L): List of integer -> real
# # {AvgElmt(L) menghasilkan bilangan riil yang merupakan rata-rata # nilai dariseluruh elemen L.}
# def AvgElmt(l:list)->float:
#     return sumlist(l)/NbElmt(l)

# print(AvgElmt([1,2,3,4,5]))


# # MaxElmt(L): List of integer -> integer
# # {MaxElmt(L) mengembalikan elemen dengan nilai maksimum dari list L.}
# def MaxElmt(l:list) -> int:
#     if isEmpty(l):
#         return 0
#     elif FirstElmt(l) > MaxElmt(Tail(l)):
#         return FirstElmt(l)
#     else:
#         return MaxElmt(Tail(l))

# print(MaxElmt([5,6,6,2]))

# # {CountN(C, T) menghasilkan banyaknya kemunculan karakter C pada list ofcharacter (T)}

# def Count(n:int,l:list) -> int:
#     if isEmpty(l):
#         return 0
#     elif FirstElmt(l) == n:
#         return 1 + Count(n,Tail(l))
#     else:
#         return 0 + Count(n,Tail(l))

# print(Count(3,[3,3,3,3,3,4]))

# # MaxNB: List of integer -> = 1> # {MaxNB(L) menghasilkan tipe bentukan yang berisikan bilangan maksimum # pada list L dan seberapa banyak bilangan itu muncul di dalam list.}
# def MaxNB(l:list) : #-> #tipe baru
#     return [MaxElmt(l),Count(MaxElmt(l),l)]

# print(MaxNB([3,6,6,6,6,4]))

# # Atleast: integer > 0, character, list of character -> boolean
# # {Atleast (N,C,T) benar, jika karakter C minimal muncul N kali pada list of character (T)}

# def Atleast(n,c,t):
#     pass
    
    