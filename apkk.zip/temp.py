def konso(e : int, l : list) -> list :
    return [e] + l
def konsi(e : int, l : list) -> list :
    return l + [e]
def FirstElmt(l:list) -> int:
    return l[0]
def LastElmt(l:list) -> int:
    return l[-1]
def Head(l:list) -> list:
    return l[:-1]
def Tail(l:list) -> list:
    return l[1:]
def isEmpty(l:list) -> bool:
    return l == []
def isOneElmt(l:list) -> bool:
    return Head(l) == [] and Tail(l) == [] and (not isEmpty(l))

def Rember2(x, L):
    """Menghapus satu kemunculan pertama x dari L."""
    if isEmpty(L):
        return []
    if FirstElmt(L) == x:
        return Tail(L)
    return konso(FirstElmt(L), Rember2(x, Tail(L)))


def MultiRember(x, L):
    """Menghapus semua kemunculan x dari L."""
    if isEmpty(L):
        return []
    if FirstElmt(L) == x:
        return MultiRember(x, Tail(L))
    return konso(FirstElmt(L), MultiRember(x, Tail(L)))


def MakeSet_Versi1(L):
    """Membuat set dengan mempertahankan kemunculan terakhir."""
    if isEmpty(L):
        return []
    if FirstElmt(L) in Tail(L):
        return MakeSet_Versi1(Tail(L))
    return konso(FirstElmt(L), MakeSet_Versi1(Tail(L)))


def MakeSet_Versi2(L):
    """Membuat set dengan mempertahankan kemunculan pertama."""
    if isEmpty(L):
        return []
    elemen = FirstElmt(L)
    return konso(elemen, MakeSet_Versi2(MultiRember(elemen, Tail(L))))


def KonsoSet(e, H):
    """Menambahkan e di awal H jika e belum menjadi anggota H."""
    if e in H:
        return H
    return konso(e, H)


def IsSet(L):
    """Mengembalikan True jika L tidak memiliki elemen duplikat."""
    if isEmpty(L):
        return True
    return FirstElmt(L) not in Tail(L) and IsSet(Tail(L))


def IsSubSet(H1, H2):
    """Mengembalikan True jika semua elemen H1 ada di H2."""
    if isEmpty(H1):
        return True
    return FirstElmt(H1) in H2 and IsSubSet(Tail(H1), H2)


def IsEqualSet_Versi1(H1, H2):
    """Membandingkan dua set menggunakan relasi subset."""
    return IsSubSet(H1, H2) and IsSubSet(H2, H1)


def IsEqualSet_Versi2(H1, H2):
    """Membandingkan keanggotaan dan jumlah elemen dua set."""
    return IsSubSet(H1, H2) and IsSubSet(H2, H1)


def IsIntersect(H1, H2):
    """Mengembalikan True jika H1 dan H2 memiliki irisan."""
    if isEmpty(H1):
        return False
    return FirstElmt(H1) in H2 or IsIntersect(Tail(H1), H2)


def MakeIntersect_Versi1(H1, H2):
    """Membuat irisan dengan urutan mengikuti H1."""
    if isEmpty(H1):
        return []
    if FirstElmt(H1) in H2:
        return konso(FirstElmt(H1), MakeIntersect_Versi1(Tail(H1), H2))
    return MakeIntersect_Versi1(Tail(H1), H2)


def MakeIntersect_Versi2(H1, H2):
    """Membuat irisan dengan urutan mengikuti H2."""
    return MakeIntersect_Versi1(H2, H1)


def MakeUnion_Versi1(H1, H2):
    """Membuat gabungan dengan elemen unik H1 lalu elemen unik H2."""
    return MakeSet_Versi2(H1 + H2)


def MakeUnion_Versi2(H1, H2):
    """Membuat gabungan dengan elemen unik H2 lalu elemen unik H1."""
    return MakeUnion_Versi1(H2, H1)


def NBIntersect(H1, H2):
    """Menghitung banyak elemen pada irisan H1 dan H2."""
    if isEmpty(H1):
        return 0
    if FirstElmt(H1) in H2:
        return 1 + NBIntersect(Tail(H1), H2)
    return NBIntersect(Tail(H1), H2)


def NBUnion(H1, H2):
    """Menghitung banyak elemen pada gabungan H1 dan H2."""
    return NBIntersect(H1, H1) + NBIntersect(MakeDifference(H2, H1), H2)


def KonsiSet(H, e):
    """Menambahkan e di akhir H jika e belum menjadi anggota H."""
    if e in H:
        return H
    return konsi(e, H)


def MakeDifference(H1, H2):
    """Membuat selisih H1 terhadap H2 dengan urutan H1."""
    if isEmpty(H1):
        return []
    if FirstElmt(H1) in H2:
        return MakeDifference(Tail(H1), H2)
    return konso(FirstElmt(H1), MakeDifference(Tail(H1), H2))


def MakeSymDifference(H1, H2):
    """Membuat selisih simetris dengan urutan H1 lalu H2."""
    return MakeDifference(H1, H2) + MakeDifference(H2, H1)


def JaccardSimilarity(H1, H2):
    """Menghitung indeks kemiripan Jaccard."""
    jumlah_union = NBUnion(H1, H2)
    if jumlah_union == 0:
        return 0.0
    return NBIntersect(H1, H2) / jumlah_union


def KonsoAll(e, LL):
    """Menambahkan e di awal setiap list dalam LL."""
    if isEmpty(LL):
        return []
    return konso(konso(e, FirstElmt(LL)), KonsoAll(e, Tail(LL)))


def PowerSet(H):
    """Menghasilkan power set dengan urutan sesuai spesifikasi."""
    if isEmpty(H):
        return [[]]

    elemen_pertama = FirstElmt(H)
    power_set_sisa = PowerSet(Tail(H))
    return power_set_sisa + KonsoAll(elemen_pertama, power_set_sisa)
